package member;

public class MemberVO {
	
}
