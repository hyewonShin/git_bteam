package member;

public class MemberADAO {

}
